Aqui estão os exercícios que faltaram do ED7 no último envio, inclui também os EXTRAS.

-No exercicio04 gravei as saidas em frações, como "1 / 36", e então no ex 07 tive problemas de leitura pois só lia o numerador (1)
Então modifiquei o ex04 para gravar só o denominado, e fazer o calculo no ex7.
