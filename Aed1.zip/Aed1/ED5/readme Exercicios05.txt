1- No exercicio 5, experimentei colocar int no numerador e denominador, e notei que ao invés de printar corretamente quando pow(5, 2) = 25, ele printava
= 24, sempre uma unidade abaixo pra todos, por que isso acontece? 

E porque se colocar %1.0lf some todas as casas fracionárias da impressão do double?

-Nos exercícios em que tem que mostrar o operador +, depois do último número, o operador está aparecendo mesmo assim, como resolver? Por exemplo: 100 + 121 +.