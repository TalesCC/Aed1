// 999999_AED1
#include <stdio.h>
#include <stdlib.h>

/*
  Metodo 01.
*/
void method_01 ( void )
{
  // definir dados
     int matrix [10][10];  // reservar area
     int m = 0; int n = 0;
     int x = 0; int y = 0; int z = 0;
  // abrir arquivo para gravar texto  
     FILE *arquivo = fopen ( "DADOS.TXT", "wt" );
  // identificar
     printf ( "999999_AED1_Method_01\n\n" );
  // acoes
  // ler quantidade de linhas
     do
     {
        printf ( "\nQuantas linhas  ? " );
        scanf  ( "%d", &m ); getchar ( );
     }
     while ( m <= 0 || 10 < m );
  // ler quantidade de colunas
     do
     {
        printf ( "\nQuantas colunas ? " );
        scanf  ( "%d", &n ); getchar ( );
     }
     while ( n <= 0 || 10 < n );
  // ler e guardar dados em matriz
     for ( x = 0; x < m; x = x+1 )   // para cada linha
     {
       for ( y = 0; y < n; y = y+1 ) // para cada coluna
       {   
           printf ( "\nz = " );
           scanf  ( "%d", &z ); getchar ( );
           matrix [x][y] = z;
       } // end for
     } // end for
  // gravar dados em arquivo
     for ( x = 0; x < m; x = x+1 )
     {
       for ( y = 0; y < n; y = y+1 )
       {   fprintf (arquivo,"%d\n",matrix[x][y]);   }
     } // end for
  // fechar arquivo
     fclose ( arquivo );
} // end method_01 ( )

/*
  Metodo 02.
*/
void method_02 ( void )
{
  // definir dados
     int matrix [10][10]; // reservar a area
     int m = 0;     int n = 0;
     int p = 0;     int q = 0;
     int x = 0;     int y = 0;    int z = 0;
  // abrir arquivo para ler texto
     FILE *arquivo = fopen("DADOS.TXT","rt");
  // identificar
     printf("999999_AED1_Method_02\n\n");
  // acoes
     do
     {
        printf ( "\nQuantas linhas  ? " );
        scanf  ( "%d", &m ); getchar ( );
     }
     while ( m <= 0 || 10 < m );
  // ler quantidade de colunas
     do
     {
        printf ( "\nQuantas colunas ? " );
        scanf  ( "%d", &n ); getchar ( );
     }
     while ( n <= 0 || 10 < n );
     fscanf( arquivo, "%d", &z );
     while ( ! feof(arquivo)
           && m < 10 && n < 10
           && p < m  && q < n )
     {
         matrix [ p ][ q ] = z;
         q = q + 1;
         if ( q >= n ) { p = p + 1; q = 0; }
         fscanf ( arquivo, "%d", &z );
     } // end for
  // mostrar dados lidos de arquivo
     for ( x = 0; x < m; x = x+1 )
     {
       for ( y = 0; y < n; y = y+1 )
       {   printf ("%4d ",matrix[x][y]);   }
       printf ( "\n" );
     } // end for
  // fechar arquivo
     fclose ( arquivo );
} // end method_02 ( )

/*
  Metodo 03.
*/
void method_03 ( void )
{
  // definir dados
     int matrix [10][10]; // reservar area
     int m = 0;     int n = 0;
     int x = 0;     int y = 0;     int z = 0;
  // abrir arquivo para gravar texto
     FILE *arquivo = fopen ( "DADOS.TXT", "wt" );
  // identificar
     printf( "999999_AED1_Method_03\n\n" );
  // acoes
     do
     {
        printf ( "\nQuantas linhas  ? " );
        scanf  ( "%d", &m ); getchar ( );
     }
     while ( m <= 0 || 10 < m );
  // ler quantidade de colunas
     do
     {
        printf ( "\nQuantas colunas ? " );
        scanf  ( "%d", &n ); getchar ( );
     }
     while ( n <= 0 || 10 < n );
  // ler e guardar dados em matriz
     for ( x = 0; x < m; x = x+1 )
     {
       for ( y = 0; y < n; y = y+1 )
       {   
           printf ( "\nz = " );
           scanf  ( "%d", &z ); getchar ( );
           matrix [x][y] = z;
       } // end for
     } // end for
  // gravar dados em arquivo
     fprintf ( arquivo,"%d\n", m ); // gravar linhas
     fprintf ( arquivo,"%d\n", n ); // gravar colunas
     for ( x = 0; x < m; x = x+1 )
     {
       for ( y = 0; y < n; y = y+1 )
       {   fprintf (arquivo,"%d\n",matrix[x][y]);   }
     } // end for
  // fechar arquivo
     fclose ( arquivo );
} // end method_03 ( )

/*
  Metodo 04.
*/
void method_04 ( void )
{
  // definir dados
     int matrix [10][10]; // reservar a area
     int m = 0;     int n = 0;
     int p = 0;     int q = 0;
     int x = 0;     int y = 0;     int z = 0;
  // abrir arquivo para ler texto
     FILE *arquivo = fopen("DADOS.TXT","rt");
  // identificar
     printf ( "999999_AED1_Method_04\n\n" );
  // acoes
  // ler dados
     fscanf ( arquivo,"%d", &m ); // ler linhas
     fscanf ( arquivo,"%d", &n ); // ler colunas
     if ( m < 10 && n < 10 )
     {
        fscanf ( arquivo, "%d", &z );
        while ( ! feof(arquivo)
              && p < m  && q < n )
        {
            matrix [ p ][ q ] = z;
            q = q + 1;
            if ( q >= n ) { p = p + 1; q = 0; }
            fscanf ( arquivo, "%d", &z );
        } // end while
     // mostrar dados
        for ( x = 0; x < m; x = x+1 )
        {
            for ( y = 0; y < n; y = y+1 )
            {   printf ("%4d ",matrix[x][y]);   }
            printf ( "\n" );
        } // end for
     } // end if
  // fechar arquivo
     fclose ( arquivo );
} // end method_04 ( )

/*
  Metodo 05.
*/
void method_05 ( void )
{
  // definir dados
     int matrix [10][10]; // reservar a area
     int m = 0;     int n = 0;
     int p = 0;     int q = 0;
     int x = 0;
     int y = 0;
     int z = 0;
  // abrir arquivo para ler texto
     FILE *arquivo = fopen("DADOS.TXT","rt");
  // identificar
     printf ( "999999_AED1_Method_05\n\n" );
  // acoes
     fscanf ( arquivo, "%d", &m );
     fscanf ( arquivo, "%d", &n );
     if ( m < 10 && n < 10 )
     {
        fscanf ( arquivo, "%d", &z );
        for ( x = 0; x < m; x = x+1 )
        {
            for ( y = 0; y < n; y = y+1 )
            {
                matrix [ x ][ y ] = z;
                fscanf ( arquivo, "%d", &z );
//              if ( feof ( arquivo ) ) break;
            } // end for
        } // end for
     } // end if
  // mostrar dados
     for ( x = 0; x < m; x = x+1 )
     {
       for ( y = 0; y < n; y = y+1 )
       {   printf ("%4d ",matrix[x][y]);   }
       printf ( "\n" );
     } // end for
  // fechar arquivo
     fclose ( arquivo );
} // end method_05 ( )

/*
  Metodo 06.
*/
void method_06 ( void )
{
  // definir dados
     int matrix [10][10]; // reservar a area
     int m = 0;     int n = 0;
     int p = 0;     int q = 0;
     int x = 0;
     int y = 0;
     int z = 0;
  // abrir arquivo para ler texto
     FILE *arquivo = fopen("DADOS.TXT","rt");
  // identificar
     printf ( "999999_AED1_Method_06\n\n" );
  // acoes
     fscanf ( arquivo, "%d", &m );
     fscanf ( arquivo, "%d", &n );
     if ( m < 10 && n < 10 )
     {
        fscanf ( arquivo, "%d", &z );
        x = 0;
        while ( ! feof (arquivo) && x < m )
        {
            y = 0;
            while ( ! feof (arquivo) && y < n )
            {
                matrix [ x ][ y ] = z;
                p = x; q = y;
                fscanf (arquivo,"%d",&z);
                y = y+1;
            } // end while
            x = x+1;
        } // end while
     } // end if
  // mostrar dados
  // printf ("\ntamanho real p=%d q=%d\n",p,q);
     if ( p == m-1 && q == n-1 )
     {
        for ( x = 0; x <= p; x = x+1 )
        {
            for ( y = 0; y <= q; y = y+1 )
            {   printf ("%4d ",matrix[x][y]);   }
            printf ( "\n" );
        } // end for
     }
     else
     {
        printf ( "\nERRO: Matriz invalida.\n\n" );
     } // end if
  // fechar arquivo
     fclose ( arquivo );
} // end method_06 ( )

/*
  Metodo 07.
*/
void method_07 ( void )
{
  // definir dados
     int matrix [10][10]; // reservar area
     int m = 0;     int n = 0;
     int x = 0;     int y = 0;      int z = 0;
  // abrir arquivo para gravar texto
     FILE *arquivo = fopen ( "DADOS.TXT", "wt" );
  // identificar
     printf ( "999999_AED1_Method_07\n" );
  // acoes
  // ler quantidade de linhas
     do
     {
        printf ( "\nQuantas linhas  ? " );
        scanf  ( "%d", &m ); getchar ( );
     }
     while ( m <= 0 || 10 < m );
  // ler quantidade de colunas
     do
     {
        printf ( "\nQuantas colunas ? " );
        scanf  ( "%d", &n ); getchar ( );
     }
     while ( n <= 0 || 10 < n );
  // ler e guardar dados em matriz
     for ( x = 0; x < m; x = x+1 )
     {
       for ( y = 0; y < n; y = y+1 )
       {   z = 20 + rand( ) % (70-20);
           matrix [x][y] = z;
       } // end for
     } // end for
  // gravar dados em arquivo
     fprintf ( arquivo, "%d\n", m );
     fprintf ( arquivo, "%d\n", n );
     for ( x = 0; x < m; x = x+1 )
     {
       for ( y = 0; y < n; y = y+1 )
       { fprintf (arquivo,"%d\n",matrix[x][y]); }
     } // end for
  // fechar arquivo
     fclose ( arquivo );
} // end method_07 ( )

/*
  Metodo 08.
*/
void method_08 ( void )
{
  // definir dados
     int m = 0;     int n = 0;
     int x = 0;     int y = 0;     int z = 0;
  // abrir arquivo para gravar texto
     FILE *arquivo = fopen ( "DADOS.TXT", "rt" );
  // identificar
     printf ( "999999_AED1_Method_08\n\n" );
  // acoes
  // testar se linhas e colunas validas
     fscanf ( arquivo, "%d", &m );
     fscanf ( arquivo, "%d", &n );
     if ( 0 < m && m < 10 && 0 < n && n < 10 )
     {
      // reservar area
         int matrix [m][n];
      // ler dados de arquivo
         fprintf ( arquivo, "%d\n", m );
         fprintf ( arquivo, "%d\n", n );
         for ( x = 0; x < m; x = x+1 )
         {
             for ( y = 0; y < n; y = y+1 )
             {
                 fscanf (arquivo,"%d",
                         &matrix[x][y]);
             } // end for
         } // end for
      // fechar arquivo
         fclose ( arquivo );
      // mostrar matriz
         for ( x = 0; x < m; x = x+1 )
         {
             for ( y = 0; y < n; y = y+1 )
             {   printf ("%4d ",matrix[x][y]);   }
             printf ( "\n" );
         } // end for
     } // end if
} // end method_08 ( )

/*
  Metodo para mostrar matriz.
  @param m      - quantidade  de linhas
  @param n      - quantidade  de colunas
  @param matrix - armazenador de dados
*/
void mostrar_int_matriz ( int m, int n,
                          int matrix [ ][10] )
{
 // definir dados locais
    int x = 0, y = 0;
 // mostrar matriz
    for ( x = 0; x < m; x = x+1 )
    {
        for ( y = 0; y < n; y = y+1 )
        {   printf ("%4d ",matrix[x][y]);   }
        printf ( "\n" );
    } // end for
} // end mostrar_int_matriz ( )

/*
  Metodo para ler dados para matriz do teclado.
  @param m      - quantidade  de linhas
  @param n      - quantidade  de colunas
  @param matrix - armazenador de dados
*/
void entrar_int_matriz ( int m, int n,
                         int matrix [ ][10] )
{
 // definir dados locais
    int x = 0, y = 0;
 // ler matriz
    for ( x = 0; x < m; x = x+1 )
    {
        for ( y = 0; y < n; y = y+1 )
        {
            scanf  ( "%d", &matrix[x][y] );
            getchar( );
        } // end for
    } // end for
} // end entrar_int_matriz ( )

/*
  Metodo para gravar matriz.
  @param filename - nome de arquivo
  @param m        - quantidade  de linhas
  @param n        - quantidade  de colunas
  @param matrix   - armazenador de dados
*/
void gravar_int_matriz ( char *filename,
                         int   m, int n,
                         int   matrix [ ][10] )
{
 // definir dados locais
    int x = 0, y = 0;
 // abrir arquivo para gravar texto
    FILE *arquivo = fopen ( filename, "wt" );
 // gravar dados em arquivo
    fprintf ( arquivo, "%d\n", m );
    fprintf ( arquivo, "%d\n", n );
    for ( x = 0; x < m; x = x+1 )
    {
        for ( y = 0; y < n; y = y+1 )
        {
            fprintf ( arquivo,"%d\n",
                      matrix[x][y] );
        } // end for
    } // end for
 // fechar arquivo
    fclose ( arquivo );
} // end gravar_int_matriz ( )

/*
  Metodo 09.
*/
void method_09 ( void )
{
  // definir dados
     int m = 0;     int n = 0;
  // identificar
     printf ( "999999_AED1_Method_09\n\n" );
  // acoes
  // testar se linhas e colunas validas
  // ler quantidade de linhas
     printf ( "\nQuantas linhas  ? " );
     scanf  ( "%d", &m ); getchar ( );
  // ler quantidade de colunas
     printf ( "\nQuantas colunas ? " );
     scanf  ( "%d", &n ); getchar ( );
     if ( 0 < m && m < 10 && 0 < n && n < 10 )
     {
      // reservar area local
         int matrix [m][10];
      // ler matriz
         entrar_int_matriz ( m, n, matrix );
      // gravar dados em arquivo
         gravar_int_matriz ("DADOS.TXT",m,n,matrix );
     } // end if
} // end method_09 ( )

/*
  Metodo para gravar matriz.
  @param filename - nome de arquivo
  @param p        - quantidade  de linhas
  @param q        - quantidade  de colunas
  @param matrix   - armazenador de dados
*/
void ler_int_matriz ( char *filename,
                   // passagem por referencia
                      int  *p, int *q,
                      int   matrix [ ][10] )
{
  // definir dados
     int m = 0;     int n = 0;
     int x = 0;     int y = 0;     int z = 0;
  // abrir arquivo para ler dados
     FILE *arquivo = fopen ( filename, "rt" );
  // testar se linhas e colunas validas
     fscanf ( arquivo, "%d", &m );
     fscanf ( arquivo, "%d", &n );
     if ( 0 < m && m < 10 && 0 < n && n < 10 )
     {
      // ler dados de arquivo
         for ( x = 0; x < m; x = x+1 )
         {
             for ( y = 0; y < n; y = y+1 )
             {
                 fscanf ( arquivo,"%d",
                         &matrix[x][y] );
             } // end for
         } // end for
      // fechar arquivo
         fclose ( arquivo );
     } // end if
  // retorno pelas referencias
     *p = m;
     *q = n;
} // end ler_int_matriz ( )

/*
  Metodo 10.
*/
void method_10 ( void )
{
  // definir dados
     int m = 0;     int n = 0;
  // reservar area
     int matrix [10][10];
  // identificar
     printf ( "999999_AED1_Method_10\n\n" );
  // acoes
  // mostrar matriz
     ler_int_matriz ( "DADOS.TXT", &m, &n, matrix );
  // mostrar matriz
     mostrar_int_matriz ( m, n, matrix );
} // end method_10 ( )

/*
  Metodo para mostrar matriz real.
  @param m      - quantidade  de linhas
  @param n      - quantidade  de colunas
  @param matrix - armazenador de dados
*/
void mostrar_double_matriz ( int m, int n,
                             double matrix [ ][10] )
{
 // definir dados locais
    int x = 0, y = 0;
 // mostrar matriz
    for ( x = 0; x < m; x = x+1 )
    {
        for ( y = 0; y < n; y = y+1 )
        {   printf ("%4.2lf ",matrix[x][y]);   }
        printf ( "\n" );
    } // end for
    printf ( "\n" );
} // end mostrar_double_matriz ( )

/*
  Metodo para ler dados para matriz real do teclado.
  @param p      - quantidade  de linhas
  @param q      - quantidade  de colunas
  @param matrix - armazenador de dados
*/
void entrar_double_matriz ( int *p, int *q,
                            double  matrix [ ][10] )
{
 // definir dados locais
    int x = 0, y = 0;
    int m = 0, n = 0;
 // ler matriz
    printf ( "\nlinhas  = " );
    scanf  ( "%d", &m );
    printf ( "\ncolunas = " );
    scanf  ( "%d", &n );
    printf ( "\n" );
    for ( x = 0; x < m; x = x+1 )
    {
        for ( y = 0; y < n; y = y+1 )
        {
            scanf  ( "%lf", &matrix[x][y] );
            getchar( );
        } // end for
    } // end for
    printf ( "\n" );
 // retornar valores lidos
    *p = m;
    *q = n;
} // end entrar_double_matriz ( )

/*
  Metodo 11.
*/
void method_11 ( void )
{
  // definir dados
     int m = 0;     int n = 0;
  // reservar area
     double matrix [10][10];
  // identificar
     printf ( "999999_AED1_Method_11\n\n" );
  // acoes
  // mostrar matriz
     entrar_double_matriz  ( &m, &n, matrix );
  // mostrar matriz
     mostrar_double_matriz (  m,  n, matrix );
} // end method_11 ( )

/*
  Metodo para gravar matriz.
  @param filename - nome de arquivo
  @param m        - quantidade  de linhas
  @param n        - quantidade  de colunas
  @param matrix   - armazenador de dados
*/
void gravar_double_matriz ( char  *filename,
                            int    m, int n,
                            double matrix [ ][10] )
{
 // definir dados locais
    int x = 0, y = 0;
 // abrir arquivo para gravar texto
    FILE *arquivo = fopen ( filename, "wt" );
 // gravar dados em arquivo
    fprintf ( arquivo, "%d\n", m );
    fprintf ( arquivo, "%d\n", n );
    for ( x = 0; x < m; x = x+1 )
    {
        for ( y = 0; y < n; y = y+1 )
        {
            fprintf ( arquivo, "%lf\n",
                      matrix[x][y] );
        } // end for
    } // end for
 // fechar arquivo
    fclose ( arquivo );
} // end gravar_double_matriz ( )

/*
  Metodo 12.
*/
void method_12 ( void )
{
  // definir dados
     int m = 0;     int n = 0;
  // reservar area
     double matrix [10][10];
  // identificar
     printf ( "999999_AED1_Method_12\n\n" );
  // acoes
  // entrar matriz
     entrar_double_matriz ( &m, &n, matrix );
  // gravar matriz
     gravar_double_matriz ( "DADOS.TXT", m, n, matrix );
} // end method_12 ( )

/*
  Metodo para ler matriz de arquivo.
  @param filename - nome de arquivo
  @param p        - quantidade  de linhas
  @param q        - quantidade  de colunas
  @param matrix   - armazenador de dados
*/
void ler_double_matriz ( char  *filename,
                         int   *p, int *q,
                         double matrix [ ][10] )
{
  // definir dados
     int m = 0;     int n = 0;
     int x = 0;     int y = 0;     int z = 0;
  // abrir arquivo para ler dados
     FILE *arquivo = fopen ( filename, "rt" );
  // testar se linhas e colunas validas
     fscanf ( arquivo, "%d", &m );
     fscanf ( arquivo, "%d", &n );
     if ( 0 < m && m < 10 && 0 < n && n < 10 )
     {
      // ler dados de arquivo
         for ( x = 0; x < m; x = x+1 )
         {
             for ( y = 0; y < n; y = y+1 )
             {
                 fscanf ( arquivo, "%lf",
                         &matrix[x][y] );
             } // end for
         } // end for
      // fechar arquivo
         fclose ( arquivo );
     } // end if
  // retorno pelas referencias
     *p = m;
     *q = n;
} // end ler_double_matriz ( )

/*
  Metodo 13.
*/
void method_13 ( void )
{
  // definir dados
     int m = 0;     int n = 0;
  // reservar area
     double matrix [10][10];
  // identificar
     printf ( "999999_AED1_Method_13\n\n" );
  // acoes
  // ler matriz
     ler_double_matriz     ( "DADOS.TXT", &m, &n, matrix );
  // mostrar matriz
     mostrar_double_matriz (  m, n, matrix );
} // end method_13 ( )

/*
  Metodo para ler matriz de arquivo (2).
  @param filename - nome de arquivo
  @param p        - quantidade  de linhas
  @param q        - quantidade  de colunas
  @param matrix   - armazenador de dados
*/
void ler_double_matriz_2 ( char  *filename,
                           int   *p, int *q,
                           double matrix [ ][10] )
{
  // definir dados
     int m = 0;     int n = 0;
     int x = 0;     int y = 0;     int z = 0;
  // abrir arquivo para ler dados
     FILE *arquivo = fopen ( filename, "rt" );
  // testar se linhas e colunas validas
     fscanf ( arquivo, "%d", &m );
     fscanf ( arquivo, "%d", &n );
     if ( 0 < m && m < 10 && 0 < n && n < 10 )
     {
      // ler dados de arquivo
         x = 0;
         while ( ! feof ( arquivo ) && x < m )
         {
             y = 0;
             while ( ! feof ( arquivo ) && y < n )
             {
                 fscanf ( arquivo, "%lf", 
                         &matrix[x][y] );
                 y = y+1;
             } // end while
             x = x+1;
         } // end while
      // fechar arquivo
         fclose ( arquivo );
     } // end if
  // retorno pelas referencias
    *p = m;
    *q = n;
} // end ler_double_matriz_2 ( )

/*
  Metodo 14.
*/
void method_14 ( void )
{
  // definir dados
     int m = 0;     int n = 0;
  // reservar area
     double matrix [10][10];
  // identificar
     printf ( "999999_AED1_Method_14\n\n" );
  // acoes
  // ler matriz
     ler_double_matriz_2   ( "DADOS.TXT", &m, &n, matrix );
  // mostrar matriz
     mostrar_double_matriz (  m, n, matrix );
} // end method_14 ( )

/*
  Metodo para ler matriz de arquivo (3).
  @param filename - nome de arquivo
  @param p        - quantidade  de linhas
  @param q        - quantidade  de colunas
  @param matrix   - armazenador de dados
*/
void ler_double_matriz_3 ( char  *filename,
                           int   *p, int *q,
                           double matrix [ ][10] )
{
  // definir dados
     int m = 0;     int n = 0;
     int x = 0;     int y = 0;     int z = 0;
  // abrir arquivo para ler dados
     FILE *arquivo = fopen ( filename, "rt" );
  // testar se linhas e colunas validas
     fscanf ( arquivo, "%d%d", &m, &n );
     if ( 0 < m && m < 10 && 0 < n && n < 10 )
     {
      // ler dados de arquivo
         x = 0;
         while ( ! feof ( arquivo ) && x < m )
         {
             y = 0;
             while ( ! feof ( arquivo ) && y < n )
             {
                 fscanf ( arquivo, "%lf", &matrix[x][y] );
                 y = y+1;
             } // end while
             x = x+1;
         } // end while
      // fechar arquivo
         fclose ( arquivo );
     } // end if
  // retorno pelas referencias
    *p = m;
    *q = n;
} // end ler_double_matriz_3 ( )

/*
  Metodo 15.
*/
void method_15 ( void )
{
  // definir dados
     int m = 0;     int n = 0;
  // reservar area
     double matrix [10][10];
  // identificar
     printf ( "999999_AED1_Method_15\n\n" );
  // acoes
  // ler matriz
     ler_double_matriz_3   ( "DADOS.TXT", &m, &n, matrix );
  // mostrar matriz
     mostrar_double_matriz (  m, n, matrix );
} // end method_15 ( )

/*
  Metodo para ler matriz de arquivo (4).
  @param filename - nome de arquivo
  @param p        - quantidade  de linhas
  @param q        - quantidade  de colunas
  @param matrix   - armazenador de dados
*/
void ler_double_matriz_4 ( char  *filename,
                           int   *p, int *q,
                           double matrix [ ][10] )
{
  // definir dados
     int m = 0;     int n = 0;
     int x = 0;     int y = 0;     int z = 0;
  // abrir arquivo para ler dados
     FILE *arquivo = fopen ( filename, "rt" );
  // testar se linhas e colunas validas
     fscanf ( arquivo, "%d%d", p, q );
     if ( 0 < *p && *p < 10 && 0 < *q && *q < 10 )
     {
      // ler dados de arquivo
         x = 0;
         while ( ! feof ( arquivo ) && x < *p )
         {
             y = 0;
             while ( ! feof ( arquivo ) && y < *q )
             {
                 fscanf ( arquivo, "%lf", &matrix[x][y] );
                 y = y+1;
             } // end while
             x = x+1;
         } // end while
      // fechar arquivo
         fclose ( arquivo );
     } // end if
} // end ler_double_matriz_4 ( )

/*
  Metodo 16.
*/
void method_16 ( void )
{
  // definir dados
     int m = 0;     int n = 0;
  // reservar area
     double matrix [10][10];
  // identificar
     printf ( "999999_AED1_Method_16\n\n" );
  // acoes
  // ler matriz
     ler_double_matriz_4   ( "DADOS.TXT", &m, &n, matrix );
  // mostrar matriz
     mostrar_double_matriz (  m, n, matrix );
} // end method_16 ( )

/*
  Metodo para ler matriz de arquivo (5).
  @param filename - nome de arquivo
  @param p        - quantidade  de linhas
  @param q        - quantidade  de colunas
  @param matrix   - armazenador de dados
*/
void ler_double_matriz_5 ( char  *filename,
                           int   *p, int *q,
                           double matrix [ ][10] )
{
  // definir dados
     int m = 0;     int n = 0;
     int x = 0;     int y = 0;     int z = 0;
  // abrir arquivo para ler dados
     FILE *arquivo = fopen ( filename, "rt" );
  // testar se linhas e colunas validas
     fscanf ( arquivo, "%d%d", p, q );
     m = *p;  n = *q; // para facilitar o uso
     if ( 0 < m && m < 10 && 0 < n && n < 10 )
     {
      // ler dados de arquivo
         x = 0;
         while ( ! feof ( arquivo ) && x < m )
         {
             y = 0;
             while ( ! feof ( arquivo ) && y < n )
             {
                 fscanf ( arquivo, "%lf", 
                         &matrix[x][y] );
                 y = y+1;
             } // end while
             x = x+1;
         } // end while
      // fechar arquivo
         fclose ( arquivo );
     } // end if
} // end ler_double_matriz_5 ( )

/*
  Metodo 17.
*/
void method_17 ( void )
{
  // definir dados
     int m = 0;     int n = 0;
  // reservar area
     double matrix [10][10];
  // identificar
     printf ( "999999_AED1_Method_17\n\n" );
  // acoes
  // ler matriz
     ler_double_matriz_5   ( "DADOS.TXT", &m, &n, matrix );
  // mostrar matriz
     mostrar_double_matriz (  m, n, matrix );
} // end method_17 ( )

/*
  Metodo para ler matriz de arquivo (6).
  @param filename - nome de arquivo
  @param p        - quantidade  de linhas
  @param q        - quantidade  de colunas
  @param matrix   - armazenador de dados
*/
void ler_double_matriz_6 ( char   filename [ ],
                           int    tamanho  [ ],
                           double matrix   [ ][10] )
{
  // definir dados
     int m = 0;     int n = 0;
     int x = 0;     int y = 0;     int z = 0;
  // abrir arquivo para ler dados
     FILE *arquivo = fopen ( filename, "rt" );
  // testar se linhas e colunas validas
     fscanf ( arquivo, "%d%d", &m, &n );
     if ( 0 < m && m < 10 && 0 < n && n < 10 )
     {
      // ler dados de arquivo
         x = 0;
         while ( ! feof ( arquivo ) && x < m )
         {
             y = 0;
             while ( ! feof ( arquivo ) && y < n )
             {
                 fscanf ( arquivo, "%lf", 
                         &matrix[x][y] );
                 y = y+1;
             } // end while
             x = x+1;
         } // end while
      // fechar arquivo
         fclose ( arquivo );
     } // end if
  // retornar tamanho
     tamanho [0] = m;
     tamanho [1] = n;
} // end ler_double_matriz_6 ( )

/*
  Metodo 18.
*/
void method_18 ( void )
{
  // definir dados
     int m = 0;     int n = 0;
     int tamanho [2] = { 0, 0 };
  // reservar area
     double matrix [10][10];
  // identificar
     printf ( "999999_AED1_Method_18\n\n" );
  // acoes
  // ler matriz
     ler_double_matriz_6   ( "DADOS.TXT", tamanho, matrix );
     m = tamanho [0];
     n = tamanho [1];
  // mostrar matriz
     mostrar_double_matriz (  m, n, matrix );
} // end method_18 ( )

/*
  Metodo para ler matriz de arquivo (7).
  @param filename - nome de arquivo
  @param p        - quantidade  de linhas
  @param q        - quantidade  de colunas
  @param matrix   - armazenador de dados
*/
void ler_double_matriz_7 ( char   filename [ ],
                           int    tamanho  [ ],
                           double matrix   [ ][10] )
{
  // definir dados
     int m = 0;     int n = 0;
     int x = 0;     int y = 0;     int z = 0;
  // abrir arquivo para ler dados
     FILE *arquivo = fopen ( filename, "rt" );
  // testar se linhas e colunas validas
     fscanf ( arquivo, "%d%d", 
             &tamanho[0], &tamanho[1] );
     m = tamanho [0]; n = tamanho [1];
     if ( 0 < m && m < 10 && 0 < n && n < 10 )
     {
      // ler dados de arquivo
         x = 0;
         while ( ! feof ( arquivo ) && x < m )
         {
             y = 0;
             while ( ! feof ( arquivo ) && y < n )
             {
                 fscanf ( arquivo, "%lf", 
                         &matrix[x][y] );
                 y = y+1;
             } // end while
             x = x+1;
         } // end while
      // fechar arquivo
         fclose ( arquivo );
     } // end if
} // end ler_double_matriz_7 ( )

/*
  Metodo 19.
*/
void method_19 ( void )
{
  // definir dados
     int m = 0;     int n = 0;
     int tamanho [2] = { 0, 0 };
  // reservar area
     double matrix [10][10];
  // identificar
     printf ( "999999_AED1_Method_19\n\n" );
  // acoes
  // ler matriz
     ler_double_matriz_7   ( "DADOS.TXT", tamanho, matrix );
     m = tamanho [0];
     n = tamanho [1];
  // mostrar matriz
     mostrar_double_matriz (  m, n, matrix );
} // end method_19 ( )

/*
  Metodo para mostrar matriz real (2).
  @param m      - quantidade  de linhas
  @param n      - quantidade  de colunas
  @param matrix - armazenador de dados
*/
void mostrar_double_matriz_2 ( int    tamanho [ ],
                               double matrix  [ ][10] )
{
 // definir dados locais
    int x = 0, y = 0;
 // mostrar matriz
    for ( x = 0; x < tamanho[0]; x = x+1 )
    {
        for ( y = 0; y < tamanho[1]; y = y+1 )
        {   printf ("%4.2lf ",matrix[x][y]);   }
        printf ( "\n" );
    } // end for
    printf ( "\n" );
} // end mostrar_double_matriz_2 ( )

/*
  Metodo 20.
*/
void method_20 ( void )
{
  // definir dados
     int tamanho [2] = { 0, 0 };
  // reservar area
     double matrix [10][10];
  // identificar
     printf ( "999999_AED1_Method_19\n\n" );
  // acoes
  // ler matriz
     ler_double_matriz_7     ( "DADOS.TXT", tamanho, matrix );
  // mostrar matriz
     mostrar_double_matriz_2 (  tamanho, matrix );
} // end method_20 ( )

// ---

/*
  Metodo para apresentar opcoes.
*/
void menu ( void )
{
  // identificar
     printf ( "\n999999_AED1\n\n" );
     printf ( "Menu\n"            );
     printf ( " 0 - Terminar  \n" );
     printf ( " 1 - Method_01   2 - Method_02\n" );
     printf ( " 3 - Method_03   4 - Method_04\n" );
     printf ( " 5 - Method_05   6 - Method_06\n" );
     printf ( " 7 - Method_07   8 - Method_08\n" );
     printf ( " 9 - Method_09  10 - Method_10\n" );
     printf ( "11 - Method_11  12 - Method_12\n" );
     printf ( "13 - Method_13  14 - Method_14\n" );
     printf ( "15 - Method_15  16 - Method_16\n" );
     printf ( "17 - Method_17  18 - Method_18\n" );
     printf ( "19 - Method_19  20 - Method_20\n" );
} // end menu ( )

/*
  Acao principal.
*/
int main ( void )
{
 // definir dados
    int opcao = 0;

 // acoes
    do
    {
       menu ( );
       printf( "Qual a opcao? " );
       scanf ( "%d", &opcao ); getchar ( );
       printf( "opcao = %d\n", opcao );
       switch ( opcao )
       {
         case  0: /* nao fazer nada */
           break;
         case  1: method_01( ); break; case  2: method_02( ); break;
         case  3: method_03( ); break; case  4: method_04( ); break;
         case  5: method_05( ); break; case  6: method_06( ); break;
         case  7: method_07( ); break; case  8: method_08( ); break;
         case  9: method_09( ); break; case 10: method_10( ); break;
         case 11: method_11( ); break; case 12: method_12( ); break;
         case 13: method_13( ); break; case 14: method_14( ); break;
         case 15: method_15( ); break; case 16: method_16( ); break;
         case 17: method_17( ); break; case 18: method_18( ); break;
         case 19: method_19( ); break; case 20: method_20( ); break;
         default:
                  printf ( "ERRO: Opcao invalida.\nApertar ENTER." );
           break;
       } // end switch
       getchar( ); // temporario
    }
    while ( opcao != 0 );
    return ( 0 );
} // end main ( )
/*
  Testes e observacoes
*/
