-Se dentro do metodo void exercicio() por exemplo, criar um objeto do tipo da struct, e definir um valor para uma variavel, como ler de um arquivo a quantidade, ao acessar esse valor na funcao acima do exercicio, o valor da variavel quantidade não  deveria estar atualizada?

-Pode verificar a lógica da função verifyValue do ex3?