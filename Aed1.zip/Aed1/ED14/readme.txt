

-Ex4 foi muito genérico e não soube qual conteúdo, então considerei caso o conteúdo estiver presente em um vetor
-Ex5 fiz com cadeia de caracteres, nao soube fazer com string