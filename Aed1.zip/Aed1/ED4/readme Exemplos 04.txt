-No exemplo 6, o que significa "chars palavra = IO_new_chars ( STR_SIZE );",
não poderia ser somente a declaração de um vetor? Exemplo = char palavra[80];.?

-Qual a diferença da ordem de "simbolo = palavra [ posicao ];" para "palavra [ posicao ] = simbolo"? 

-O que significa "strcpy(digitos, STR_EMPTY); //vazio"?
