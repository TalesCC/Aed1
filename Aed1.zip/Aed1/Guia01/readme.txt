1.Na compilação do Guia0101 havia um erro de falta de ";" na linha 71, o robô se movimentou num quadrado de 3 blocos 1-3, 3-3, 3-1.
2.Execução do Guia0102 foi a mesma da 01.
3.Na execução do Guia0103 o robô movimentou em um quadrado em 4 espaços e depois novamente em um quadrado menor em 3 espaços.
4.Na execução do Guia0104, o robô ao passar no ponto (4,4) "apanhou" ou apagou a marcação (1). Depois se moviemntou da mesma forma como no 3.
5.No Guia0105 o robô colocou o marcador no ponto (4,1) com sucesso com o comando putBeeper();.
6.Na Guia0106 o movimento foi até (7,7) e ao chegar em 7 do ST, mostrou o ERROR: No beeper. Como resolver?
7.Na Guia0107 não desapareceu o marcador na posição 4.4, e não soube tirar,com os dois comandos "if" antes de pick and put beeper, o robo se moveu até o ponto (7,7) e contornou, e depois, contornou um quadrado no ponto (3,3).Quando colocado o if antes de pick beeper somente ou, de putBeeper somente, ao chagar no ponto(7,1) mostrava o ERROR: no beeper.
8.No teste 08 o robô contornou um quadrado inteiro passando pelo ponto (7,7), e depois o mesmo no ponto (3,3), da mesma forma como a anterior, e, o marcador no ponto (4,4) continuou.
9.Na versão 09, o robô se moveu da mesma forma que na anterior, contornando 2 quadrados no eixo dos pontos (7,7) e (3,3) respectivamente.
1.0 Houve um erro na linha 53, no comando "for", e não soube resolver, e sumiu a parte de baixo da tela onde aparecia os erros, e compilando manualmente pelo terminal, não soube corrigir o erro.
OBS: Os exercícios, pelo erro que impediu de ser compilado, não iria conseguir compilar o arquivo modificado e, não soube como realizar os exercícios.