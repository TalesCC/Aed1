Tales Rocha Moreira - 2287559
Consegui refazer a Guia0110 corrigindo o erro anterior.
1. Com esclarecimentos na aula e de mentores do grupo de estudos, ficou mais claro como o código funciona. Dentro da função int main() do código, comentei a função doTaksk() para que ela não
fosse chamada, pois o movimento do robô foi feito todo manualmente código por código sem chamar nenhuma função. Todos os marcadores foram colocados nas posições e, retornou a posição inicial virado para o leste.
O exercício 2, copiei o código do Guia0111.cpp e colei no arquivo Guia0112.cpp a fim de ser o arquivo destinado a execução do exercício 2.
2. No nº2, adicionei os marcadores no world->set(x, y, BEEPER), dentro da int main(), continuei com cada código manualmente sem chamar outras funções, para ele fazer o caminho inverso, refiz os códigos de movimentos. OBS:Para achar os códigos de "faceSouth" e "faceNorth", a ferramenta do VSCODE ajudou a descobrir mostrando as opções disponíveis quando comecei a digitar as palavras chave.
3.Usei os mesmos códigos do exercício anterior para a captura dos beepers que já começaram no mundo.Refiz da parte em
que Karel pegava o último marcador e então, manualmente sem chamar nenhuma função fiz a trajetória e descarreguei nas
posições indicadas com o putBeeper().
4.Não soube despejar todos os marcadores em um código só. Foram 3 putBeeper(); para despejar todos no X.
5.Tudo manualmente, sem usar funções.
E1. Testei e pesuisei como usar a repetição com if e for, a função está antes da chave de fechamento da class MyRobot.
E2. Na mesma função da anterior, coloquei 6 valores para o int contador e, caso ele fosse maior que 0, retirasse 1 da execução.



