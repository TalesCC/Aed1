-O ex7, nao consegui fazer uma logica que mostrasse tanto a diagonal quanto os valores abaixo juntas, entao mostrei a diagonal com a logica do ex4, e fiz um if 
para mostrar os valores abaixo. Pode conferir?

-EXTRA02 esta imprimindo lixo na saida, o que esta acontecendo?