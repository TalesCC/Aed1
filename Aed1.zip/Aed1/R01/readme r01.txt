- No ex 3, a ultima função, "int simbolos(simbolo)" não está funcionando direito
E por que o  getchar nesse exercicio só funcionou com 2 getchar?