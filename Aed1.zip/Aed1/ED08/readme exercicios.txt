-Em alguns exercicios, como começar os testes a partir da primeira posição? 
Pois em alguns casos o primeiro valor lido do arquivo foi usado para indicar a quantidade de valores abaixo dele.
-No extra 2, consegui verificar todas as que satisfazem a condição, mas como verificar especificamente os 10 primeiros?