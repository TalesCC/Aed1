-Que warning é esse? : ISO C++ forbids converting a string constant to 'char*' [-Wwrite-strings]
Deu em praticamente todos os exercicios. Mas não interferiu na execução.