
 -No EX8, a contagem dos impares esta assim: 1 2 3 4 5, mas como fazer a impressão de somente 5? ao inves de printar de 1 em 1.

 -Exercicio10 Não está funcionando corretamente.

 -Extra2 não está correto.