No exemplo 06, não printou nada na tela após printar "Entrar com outro valor inteiro: ". Não era esperado ter um valor vindo de "printf ( "%s(%i)*(%i) = (%d)\n", "z = ", x, y, z );"?
-O que é "%p"? Formato para endereço?
-No exemplo 07 a saída foi:" x = (null)
z = (0)*(1073741824) = (0)",  isso é o esperado? Com entrada 2.0 e 3.0.
