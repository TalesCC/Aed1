-Primeiramente, fiz todos os exemplos e exercícios um por um, estão apenas no mesmo arquivo separado por métodos."Exemplo03"


-Antes da int main(), observo que sempre há "/* @return codigo de encerramento */", gostaria de saber, o que é esse "@return"? Ele faz a diferença no código?


-O que faz a IO_concat?? Olhei o que estava dentro dela na io.h e não consegui entender. Não soube o que era buffer nem a estrutura do que estava dentro.


-E o que faz o IO_pause? Não entendi a "IO_pause ( IO_concat ( "Valor diferente das opcoes [0,1] (",
IO_concat ( IO_toString_d ( x ), ")" ) ) );"


-Qual código seria a IO_pause sem a biblioteca IO? Um código diferente dele equivalente a ele?

-No exemplo 7, o x não é usado, então ele é dispensável? apaguei ele do código para testar e não houve diferença.

-No exemplo 09, no for onde x = x - passo , caso o limite superior seja 5 e o passo seja 2, significa que o passo irá subtrair de 2 em 2 em 5?

-Não entendi como funciona a confirmação de validade do exemplo 10