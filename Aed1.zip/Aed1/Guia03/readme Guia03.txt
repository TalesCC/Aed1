0302- Porque a mudança de VOID countCommands para INT?
Em todas as modificações até a 0303, a saída foi a mesma, com commands = 0, não entendi o que é: o const char,s fileName,
std::ifstream, e lenghtf.

Na 0307, não compreendi o que quer dizer com "for ( street=1; street<=world->streets( ); street=street+1 )".
